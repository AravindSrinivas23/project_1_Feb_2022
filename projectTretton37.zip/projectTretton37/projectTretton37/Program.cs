﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace projectTretton37
{
    class Program
    {
        private const string url = "https://tretton37.com/";
        static void Main(string[] args)
        {
            WebClient webclient = new WebClient();
            webclient.OpenReadCompleted += Wb_OpenReadCompleted;
            Uri Urladdress = new Uri(url);
            Console.WriteLine("Downloading Files \n\n ");
            webclient.OpenReadAsync(Urladdress);
            Console.ReadKey();
        }
        private static void Wb_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                try
                {
                    string ExePath = Assembly.GetEntryAssembly().Location;
                    ExePath = Path.GetDirectoryName(ExePath) + @"\tretton37";
                    if (Directory.Exists(ExePath))
                        Directory.Delete(ExePath, true);
                    string[] regexpatterns = new string[] { "</?(link|link).*?>","</?(img|img).*?>",
                        @"a href=""(?<link>.+?)""", @"script src=""(?<link>.+?)""",
                    @"img src=""(?<link>.+?)""",@"link rel=""(?<link>.+?)""" , @"link href=""(?<link>.+?)""",
                    @"meta content=""(?<link>.+?)"""};
                    TextReader Tr = new StreamReader(e.Result);
                    string content = Tr.ReadToEnd();
                    foreach (string regpatt in regexpatterns)
                    {
                        Regex regex = new Regex(regpatt, RegexOptions.IgnoreCase);
                        MatchCollection Mc = regex.Matches(content);
                        WebClient wClient = new WebClient();
                        string sUrl = string.Empty;
                        foreach (Match match in Mc)
                        {
                            wClient = new WebClient();
                            sUrl = url + match.Groups["link"];
                            string sdirName = string.Empty;
                            string directory = string.Empty;
                            string extension = string.Empty;
                            string imgpath = string.Empty;
                            string tempdir = string.Empty;
                            if ((!match.Groups["link"].ToString().Contains("http") && !match.Groups["link"].ToString().Contains("https")))
                            {
                                if (match.Groups["link"].Value.Contains("/") || match.Groups[0].Value.Contains("/"))
                                {
                                    if (!string.IsNullOrWhiteSpace(match.Groups["link"].Value) && match.Groups["link"].Value.Split('/').Count() > 0 && match.Groups["link"].Value.Split('/').Count() <= 3)
                                        sdirName = match.Groups["link"].Value.Split('/')[0] == "" ? match.Groups["link"].Value.Split('/')[1] : match.Groups["link"].Value.Split('/')[0];
                                    else if (!string.IsNullOrWhiteSpace(match.Groups[0].Value))
                                    {
                                        directory = GetMuiltiDirectoryPath(match.Groups[0].Value, ExePath, out extension, out imgpath, out tempdir);
                                        if (!string.IsNullOrWhiteSpace(imgpath) && !directory.Contains("rel"))
                                        {
                                            if (!Directory.Exists(directory))
                                                Directory.CreateDirectory(directory);
                                        }
                                    }
                                    else
                                    {
                                        directory = directory = GetMuiltiDirectoryPath(match.Groups["link"].Value, ExePath, out extension, out imgpath, out tempdir);
                                        if (!Directory.Exists(directory))
                                            Directory.CreateDirectory(directory);
                                    }
                                }
                                else
                                    sdirName = match.Groups["link"].ToString();
                            }
                            string ext = !string.IsNullOrWhiteSpace(extension) ? extension : System.IO.Path.GetExtension(match.Groups["link"].ToString());
                            string filename = string.Empty;
                            if (!string.IsNullOrEmpty(sdirName))
                            {
                                directory = ExePath + @"\" + sdirName;
                                if (!Directory.Exists(directory))
                                    Directory.CreateDirectory(directory);
                            }
                            if (match.Groups["link"].ToString().Contains("http") || match.Groups["link"].ToString().Contains("https"))
                            {
                                sUrl = match.Groups["link"].ToString();
                                string surlpattern = @"^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)";
                                Regex urlreg = new Regex(surlpattern, RegexOptions.IgnoreCase);
                                MatchCollection urlmatch = urlreg.Matches(match.Groups["link"].ToString());
                                string pagename = string.Empty;
                                if (urlmatch != null && urlmatch.Count > 0)
                                    pagename = urlmatch[0].Groups[1].ToString().Split('.')[0];
                                directory = ExePath + @"\" + pagename;
                                if (!Directory.Exists(directory))
                                    Directory.CreateDirectory(directory);
                                ext = (ext.Contains("js") || ext.Contains("css")) ? ext : ".html";
                                filename = directory + @"\" + pagename + (!string.IsNullOrWhiteSpace(ext) ? (ext.Contains(".") ? ext : "." + ext) : ".html");
                                wClient.DownloadFileAsync(new Uri(sUrl), filename);
                            }
                            else
                            {
                                if (!string.IsNullOrWhiteSpace(match.Groups["link"].ToString()) && match.Groups["link"].Length > 1)
                                {
                                    sUrl = url + match.Groups["link"];
                                    
                                    if (System.IO.Path.HasExtension(match.Groups["link"].ToString()))
                                        filename = directory + @"\" + System.IO.Path.GetFileNameWithoutExtension(match.Groups["link"].ToString()) + (ext.Contains(".") ? ext : "." + ext);
                                    else
                                        filename = directory + @"\" + match.Groups["link"].ToString().Replace(@"/", "") + (!string.IsNullOrWhiteSpace(ext) ? (ext.Contains(".") ? ext : "." + ext) : ".html");
                                    wClient.DownloadFileAsync(new Uri(sUrl), filename);
                                }
                                else if (!string.IsNullOrWhiteSpace(extension) && !string.IsNullOrWhiteSpace(imgpath)
                                    && !directory.Contains("rel"))
                                {
                                    sUrl = url + imgpath;
                                    filename = directory + imgpath;
                                    wClient.DownloadFileAsync(new Uri(sUrl), filename);
                                    if ((ext.Contains("jpg") || extension.Contains("jpg"))
                                        || (ext.Contains("png") || extension.Contains("png"))
                                        || (ext.Contains("gif") || extension.Contains("gif"))
                                        || (ext.Contains("ico") || extension.Contains("ico")))
                                    {
                                        sUrl = url + tempdir.Replace(@"\", "/") + imgpath.Replace(@"\", "/");
                                        WebClient client = new WebClient();
                                        if (!client.DownloadString(sUrl).Contains("404"))
                                        {
                                            Stream stream = client.OpenRead(sUrl);
                                            Bitmap bitmap; bitmap = new Bitmap(stream);
                                            if (bitmap != null)
                                            {
                                                switch (ext)
                                                {
                                                    case "jpg":
                                                        bitmap.Save(filename, ImageFormat.Jpeg);
                                                        break;
                                                    case "png":
                                                        bitmap.Save(filename, ImageFormat.Png);
                                                        break;
                                                    case "gif":
                                                        bitmap.Save(filename, ImageFormat.Gif);
                                                        break;
                                                    case "ico":
                                                        bitmap.Save(filename, ImageFormat.Icon);
                                                        break;
                                                }
                                            }
                                            System.Threading.Thread.Sleep(5000);
                                            stream.Flush();
                                            stream.Close();
                                            client.Dispose();
                                        }
                                    }
                                }
                            }
                            Console.WriteLine("\n Downloading "+ sUrl);
                            wClient.Dispose();
                        }
                        Tr.Close();
                    }
                    Console.WriteLine("\n\t\t\t-----------------------------");
                    Console.WriteLine("\n\n\t\t Downloading Completed ");
                    Console.WriteLine("\t\t\t\n-----------------------------");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("-----------------------------");
                    Console.WriteLine("\n " + ex.Message);
                    Console.WriteLine("-----------------------------");
                }
            }
        }
        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
        private static string GetMuiltiDirectoryPath(string value, string exePath, out string extension, out string imgpath, out string tempdir)
        {
            string[] multidir = value.Split('/');
            tempdir = string.Empty;
            extension = string.Empty;
            string tempFilepath = string.Empty;
            imgpath = string.Empty;
            foreach (string dir in multidir)
            {
                if (!dir.Contains(".") && !dir.Contains("/") && !dir.Contains(@"\")
                    && !dir.Contains("href") && !dir.Contains("link") && !dir.Contains("<") && !dir.Contains(">")
                    && !dir.Contains("script") && !dir.Contains("src"))
                {
                    if (!string.IsNullOrEmpty(dir))
                    {
                        tempdir += @"\" + dir;
                    }
                }
                else if (dir.Contains(".") && !dir.Contains("www") && !dir.Contains("http")
                    && !dir.Contains("https") && !dir.Contains(".com")
                    && !dir.Contains("script") && !dir.Contains("src"))
                {
                    extension = dir.Split('.')[1].Split('>')[0].Replace("\"", "");
                }

                if (!dir.Contains("href") && !dir.Contains("www") && !dir.Contains("http") && !dir.Contains("https") && !dir.Contains(".com"))
                {
                    if (dir.Contains("."))
                    {
                        imgpath = @"\" + dir.Split('.')[0] + "." + dir.Split('.')[1].Split('>')[0].Replace("\"", "");
                    }
                }
            }
            return exePath + @"\" + tempdir;
        }
    }
}
